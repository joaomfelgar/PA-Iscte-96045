

abstract class JSonValue{
    abstract fun serialize(): String


}
class JsonString(s:String): JSonValue(){

    val valor=s

    override fun serialize(): String {
        return valor.toString()
    }

}

class JsonInt(i:Int): JSonValue(){

    val valor=i

    override fun serialize(): String {
        return valor.toString()
    }

}

class JsonBoolean(b:Boolean): JSonValue(){

    val valor=b
    override fun serialize(): String{
        if(valor){
            return "true"
        }
        return "false"
    }

}

class JsonArray : JSonValue(){
    val list: MutableList<JSonValue> = mutableListOf()

    fun addElement(value:JSonValue){
        list.add(value)}

    fun contains(e:JSonValue): Boolean {
        return e in list

    }

    override fun serialize(): String {
        var lista2="[ "
        list.forEach{

                lista2 = lista2 + ""+ it.serialize() +","


        }

        return lista2+" ]"
    }

    fun searchFor(e:JSonValue): String {
        var lista = JsonArray()
        list.forEach{
            if(it==e){
                lista.addElement(it)
            }

        }
        return lista.serialize()

    }



}
data class JsonPair(val a: String, val b:JSonValue){

}
class MyJsonObject(): JSonValue() {
    val newLista = mutableListOf<JsonPair>()



    fun addField(s:String, j: JSonValue){

        newLista.add(JsonPair(s,j))
    }
    override fun serialize(): String{
        var resultado=""
        newLista.forEach {

                resultado = resultado + "\n " + "\""+ it.a +"\"" + ": " +"\""+ it.b.serialize() + "\""+" , \n"


        }

    return "{\n "+ resultado+ " \n}"
    }
}




fun main(){
    var jsonstring= JsonString("OI")
    var jsonstring2= JsonString("OI2")
    var jsonint = JsonInt(2)
    println(jsonstring is  JSonValue)

    var jsonarray = JsonArray()

    jsonarray.addElement(jsonstring)
    jsonarray.addElement(jsonstring)
    jsonarray.addElement(jsonstring2)
    jsonarray.addElement(jsonint)



    var jsonarray2 = JsonArray()
    jsonarray2.addElement(jsonstring)
    jsonarray2.addElement(jsonstring)
    jsonarray2.addElement(jsonstring2)
    jsonarray2.addElement(jsonint)

    jsonarray.addElement(jsonarray2)

    var new= jsonarray.searchFor(jsonint)

    println(new)


    var newjsononbject = MyJsonObject()
    newjsononbject.addField("Palavra", jsonstring)
    newjsononbject.addField("Palavra", jsonint)
    newjsononbject.addField("Palavra", jsonarray)

    println(newjsononbject.serialize())



}


